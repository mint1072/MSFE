---
description: Improve your YOLO's performance and measure its speed. Benchmark utility for YOLOv5.
keywords: Ultralytics YOLO, ProfileModels, benchmark, model inference, detection
---

## ProfileModels
---
### ::: ultralytics.yolo.utils.benchmarks.ProfileModels
<br><br>

## benchmark
---
### ::: ultralytics.yolo.utils.benchmarks.benchmark
<br><br>
