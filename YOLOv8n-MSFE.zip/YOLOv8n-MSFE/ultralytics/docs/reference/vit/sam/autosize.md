---
description: Learn how to use the ResizeLongestSide module in Ultralytics YOLO for automatic image resizing. Resize your images with ease.
keywords: ResizeLongestSide, Ultralytics YOLO, automatic image resizing, image resizing
---

## ResizeLongestSide
---
### ::: ultralytics.vit.sam.autosize.ResizeLongestSide
<br><br>