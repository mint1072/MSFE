---
description: Learn about the SamAutomaticMaskGenerator module in Ultralytics YOLO, an automatic mask generator for image segmentation.
keywords: SamAutomaticMaskGenerator, Ultralytics YOLO, automatic mask generator, image segmentation
---

## SamAutomaticMaskGenerator
---
### ::: ultralytics.vit.sam.modules.mask_generator.SamAutomaticMaskGenerator
<br><br>